#!/bin/sh
feh --bg-scale /usr/share/endeavouros/backgrounds/endeavouros-wallpaper.png
# picom & disown # --experimental-backends --vsync should prevent screen tearing on most setups if needed
xrandr --output Virtual1 --mode 1920x1080 --rate 60

# Start welcome
eos-welcome & disown

/usr/lib/polkit-gnome/polkit-gnome-authentication-agent-1 & disown # start polkit agent from GNOME
